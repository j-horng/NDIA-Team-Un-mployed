﻿A (frames/IMU) â†’ B (tiles/DEM + /imagery) â†’ C (ORBâ†’RANSAC, optional PnP+DEM) â†’ D (PX4 EKF2 via MAVLink).
