﻿#!/usr/bin/env python
print("Init data/tiles and a sample metadata JSON; place PNG tiles manually.")
