﻿#!/usr/bin/env bash
echo "Create demo folders and copy sample tiles/video/imu here."
