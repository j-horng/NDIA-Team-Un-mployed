﻿#!/usr/bin/env bash
echo "PX4 SITL placeholder. Configure home to config/params.yaml AOI."
