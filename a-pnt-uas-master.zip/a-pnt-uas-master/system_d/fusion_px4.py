﻿print("System D fusion bridge placeholder. Read logs/metrics.jsonl â†’ send GPS_INPUT via pymavlink")
